//pouchDB
importScripts('https://cdn.jsdelivr.net/npm/pouchdb@7.0.0/dist/pouchdb.min.js');
importScripts('js/pouchdb.min.js');
importScripts('js/sw-db.js');
importScripts('js/sw-utils.js');

const CACHE_STATIC_NAME  = 'mate-1';
const CACHE_DYNAMIC_NAME = 'dynamic-mate-v1';
const CACHE_INMUTABLE_NAME = 'inmutable-mate-v1';

const INMUTABLE = [
    'https://getbootstrap.com/docs/5.2/dist/css/bootstrap.min.css',
    'https://getbootstrap.com/docs/5.2/assets/css/docs.css',
    'https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css',
    'https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js',
    'https://cdn.jsdelivr.net/npm/pouchdb@7.0.0/dist/pouchdb.min.js'
];

const APP_SHELL = [
    '/PWA/mate/',
    '/PWA/mate/index.php',
    '/PWA/mate/img/1.png',
    '/PWA/mate/img/2.png',
    '/PWA/mate/img/3.png',
    '/PWA/mate/img/4.png',
    '/PWA/mate/img/cargando.gif',
    '/PWA/mate/js/bootstrap.js',
    '/PWA/mate/js/jquery-ui.js',
    '/PWA/mate/js/jquery-1.12.4.min.js'
];

self.addEventListener("install", e => {
    console.log("Sevice worker instaldo");
    const cacheAPP_SHELL = caches.open( CACHE_STATIC_NAME )
        .then( cache => {
            return cache.addAll( APP_SHELL );       
        })
        .catch((err) => console.log("Error al registrar cache appShell",err));

    const cache_INMUTABLE = caches.open ( CACHE_INMUTABLE_NAME )
        .then ( cache => {
            return cache.addAll( INMUTABLE );
        })
        .catch((err) => console.log("Error al registrar cache inmutable",err)); 
    
        e.waitUntil( Promise.all([cacheAPP_SHELL, cache_INMUTABLE]) );
});

self.addEventListener("active", e => {
    console.log("Sevice worker activado");
    //caches.delete(CACHE_NAME).then (console.log);
});


self.addEventListener("fetch", e => {
        console.log("Evento fetch");
        let respuesta;
        if ( e.request.url.includes('/api') ) {
            // return respuesta????
            console.log('Eventeo Fech manejar mensajes');
            console.log(e.request);
            respuesta = manejoApiMensajes( CACHE_DYNAMIC_NAME, e.request );
        } else {
            respuesta = caches.match( e.request ).then( res => {
            if ( res ) {
                actualizaCacheStatico( CACHE_STATIC_NAME, e.request, APP_SHELL );
                return res;
            } else {
                return fetch( e.request ).then( newRes => {
                    return actualizaCacheDinamico( CACHE_DYNAMIC_NAME, e.request, newRes );
                });
            }
        });
    }
    e.respondWith( respuesta );
});



//Asíncronas
self.addEventListener('sync', e => {

    console.log('SW: Sync', e.tag);

    if ( e.tag === 'nuevo-post' ) {

        // postear a BD cuando hay conexión
        const respuesta = postearMensajes();
        
        e.waitUntil( respuesta );
    }

});